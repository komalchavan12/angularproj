export interface Istore{
    id:number;
    pname:string;
    pamount:number;
    pquantity:number;
}