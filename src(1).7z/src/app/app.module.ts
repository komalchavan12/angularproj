import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule}from '@angular/forms';
import { AppComponent } from './app.component';
import { Route,RouterModule } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';

import { HomeComponent } from './home/home.component';
import { AddItemsComponent } from './add-items/add-items.component';
import { BalanceComponent } from './balance/balance.component';
 

const routes: Route []=[
  
   
  {
    path : 'home',
    component : HomeComponent},
   {path:'add-items',component:AddItemsComponent
  },
  {path:'balance',component:BalanceComponent
  },
]
  
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,AddItemsComponent, BalanceComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
