import { TestBed } from '@angular/core/testing';

import { StorelistService } from './storelist.service';

describe('StorelistService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StorelistService = TestBed.get(StorelistService);
    expect(service).toBeTruthy();
  });
});
